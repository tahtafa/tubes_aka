/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aka;

/**
 *
 * @author mac
 */
import java.util.ArrayList;

public class Search {
    public static Produk sequentialSearchIterative(ArrayList<Produk> list, String n) {
        int i = 0;
        while (i < list.size()) {
            if (list.get(i).kodeBPOM.equals(n)) {
                return list.get(i);
            }
            i++;
        }
        return null; 
    }

    public static Produk sequentialSearchRecursive(ArrayList<Produk> list, String target, int index) {
    // Basis kasus: jika indeks lebih besar atau sama dengan ukuran list, atau jika ditemukan produk yang cocok
    if (index >= list.size() || list.get(index).kodeBPOM.equals(target)) {
        return index < list.size() ? list.get(index) : null;
    }

    // Rekursif: lanjutkan pencarian ke indeks berikutnya
    return sequentialSearchRecursive(list, target, index + 1);
}
}

