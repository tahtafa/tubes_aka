/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aka;

/**
 *
 * @author mac
 */
import javax.swing.SwingUtilities;

public class AKA {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SearchComparisonGUI searchGUI = new SearchComparisonGUI();
            searchGUI.setVisible(true);
        });
    }
}

